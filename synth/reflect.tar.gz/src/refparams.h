c	parameters for reflectivity
c	ntmax = max # of samples in records (power of 2)
c	npmax = max # of slowness samples
c	maxlyr = max # of layers in model
c	maxstn = max # of stations
	parameter (ntmax=65536)
	parameter (nt3max=3*ntmax)
	parameter (ndimwr=15*(1+ntmax/2))
	parameter (npmax=9999)
	parameter (maxlyr=999)
	parameter (maxstn=500)
